clear all;
clc;

x = 0:0.1:36;% mm
t = 0.00264;
F = 3.7/506.0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
file = 'XJ3E.txt';
a= load(file);
xdata = a(:,1);ydata = a(:,2);
err = a(:,3);

r = 1.9;
modelfun_n_m = @(b,x)((r-1)*t*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r));
[beta,R,J,CovB,MSE,ErrorModelInfo]=nlinfit(xdata,ydata,modelfun_n_m,[0.0,0.0]);
alpha = 0.05;
ci = nlparci(beta,R,J,alpha); % 95% confidence intervals,
n = tinv(1-alpha/2,length(ydata)-length(beta));
nlinfit_se = (ci(:,2)-ci(:,1)) ./ (2*n)  % Standard Error
[ypred,delta] = nlpredci(modelfun_n_m,x,beta,R,'Covar',CovB,...
                         'MSE',MSE,'SimOpt','on');                    
lower = ypred - delta;
upper = ypred + delta;

figure()
h=gca;%���������
box on;
p1 = plot(xdata,ydata,'r o','MarkerFaceColor','r') %���ݵ�
%%%p7 = plot(xdata,ydata,'r o','MarkerFaceColor','r') % observed data ʵ��
hold on
p2 = plot(x,ypred,'r-','LineWidth',1) %���������
plot(x,[lower;upper],'r--','LineWidth',0.5) %��������
errorbar(xdata,ydata,err,'r o') %���

xlabel('Depth (mm)')
ylabel('Norm. Sens. Corr. IRSL (Ln/Tn)')
mu_XJ3E = beta(1);
phi_XJ3E = beta(2);
phi = beta(2);
mu_XJ3E_sigma = num2str(nlinfit_se(1));
phi_XJ3E_sigma = num2str(nlinfit_se(2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
file = 'XJ1.txt';
a= load(file);
xdata = a(:,1);ydata=a(:,2);
err = a(:,3);
modelfun_n_m = @(b,x)((r-1)*phi*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r));
[beta,R,J,CovB,MSE,ErrorModelInfo]=nlinfit(xdata,ydata,modelfun_n_m,[0.0,0.0]);
alpha = 0.05;
ci = nlparci(beta,R,J,alpha); % 95% confidence intervals,
n = tinv(1-alpha/2,length(ydata)-length(beta));
nlinfit_se = (ci(:,2)-ci(:,1)) ./ (2*n)  % Standard Error
[ypred,delta] = nlpredci(modelfun_n_m,x,beta,R,'Covar',CovB,...
                         'MSE',MSE,'SimOpt','on');   

lower = ypred - delta;
upper = ypred + delta;
p3 = plot(xdata,ydata,'b s','MarkerFaceColor','b') % observed data
hold on
p4 = plot(x,ypred,'b ','LineWidth',2)
plot(x,[lower;upper],'b--','LineWidth',0.5)
errorbar(xdata,ydata,err,'b s')
mu_XJ1 = beta(1);
mu_XJ1_sigma = num2str(nlinfit_se(1));
t_XJ1 = beta(2);
t_XJ1_sigma = num2str(nlinfit_se(2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
file = 'XJ2.txt';
a= load(file);
xdata = a(:,1);ydata=a(:,2);
err = a(:,3);

modelfun_n_m = @(b,x)((r-1)*phi*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r));
[beta,R,J,CovB,MSE,ErrorModelInfo]=nlinfit(xdata,ydata,modelfun_n_m,[0.0,0.0]);
alpha = 0.05;
ci = nlparci(beta,R,J,alpha); % 95% confidence intervals,
n = tinv(1-alpha/2,length(ydata)-length(beta));
nlinfit_se = (ci(:,2)-ci(:,1)) ./ (2*n)  % Standard Error
[ypred,delta] = nlpredci(modelfun_n_m,x,beta,R,'Covar',CovB,...
                         'MSE',MSE,'SimOpt','on');   

lower = ypred - delta;
upper = ypred + delta;
%figure()
p5 = plot(xdata,ydata,'b o','MarkerFaceColor','b') % observed data
hold on
p6 = plot(x,ypred,'b -.','LineWidth',2)
plot(x,[lower;upper],'b--','LineWidth',0.5)
errorbar(xdata,ydata,err,'b o')
mu_XJ2 = beta(1);
mu_XJ2_sigma = num2str(nlinfit_se(1));
t_XJ2 = beta(2);
t_XJ2_sigma = num2str(nlinfit_se(2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
file = 'XJ6.txt';
a= load(file);
xdata = a(:,1);ydata=a(:,2);
err = a(:,3);

modelfun_n_m = @(b,x)((r-1)*phi*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r));
[beta,R,J,CovB,MSE,ErrorModelInfo]=nlinfit(xdata,ydata,modelfun_n_m,[0.0,0.0]);
alpha = 0.05;
ci = nlparci(beta,R,J,alpha); % 95% confidence intervals,
n = tinv(1-alpha/2,length(ydata)-length(beta));
nlinfit_se = (ci(:,2)-ci(:,1)) ./ (2*n)  % Standard Error
[ypred,delta] = nlpredci(modelfun_n_m,x,beta,R,'Covar',CovB,...
                         'MSE',MSE,'SimOpt','on');   

lower = ypred - delta;
upper = ypred + delta;
%figure()
p7 = plot(xdata,ydata,'b ^','MarkerFaceColor','b') % observed data
hold on
p8 = plot(x,ypred,'b :.','LineWidth',2)
plot(x,[lower;upper],'b--','LineWidth',0.5)
errorbar(xdata,ydata,err,'b ^')
mu_XJ6 = beta(1);
mu_XJ6_sigma = num2str(nlinfit_se(1));
t_XJ6 = beta(2);
t_XJ6_sigma = num2str(nlinfit_se(2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
file = 'XJ13.txt';
a= load(file);
xdata = a(:,1);ydata=a(:,2);
err = a(:,3);

mmodelfun_n_m = @(b,x)((r-1)*phi*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r));
[beta,R,J,CovB,MSE,ErrorModelInfo]=nlinfit(xdata,ydata,modelfun_n_m,[0.0,0.0]);
alpha = 0.05;
ci = nlparci(beta,R,J,alpha); % 95% confidence intervals,
n = tinv(1-alpha/2,length(ydata)-length(beta));
nlinfit_se = (ci(:,2)-ci(:,1)) ./ (2*n)  % Standard Error
[ypred,delta] = nlpredci(modelfun_n_m,x,beta,R,'Covar',CovB,...
                         'MSE',MSE,'SimOpt','on');   

lower = ypred - delta;
upper = ypred + delta;
%figure()
p9 = plot(xdata,ydata,'b d') % observed data
hold on
p10 = plot(x,ypred,'b -','LineWidth',1)
plot(x,[lower;upper],'b--','LineWidth',0.5)
errorbar(xdata,ydata,err,'b d')
mu_XJ13 = beta(1);
mu_XJ13_sigma = num2str(nlinfit_se(1));
t_XJ13 = beta(2);
t_XJ13_sigma = num2str(nlinfit_se(2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
file = 'XJ33.txt';
a= load(file);
xdata = a(:,1);ydata=a(:,2);
err = a(:,3);

mmodelfun_n_m = @(b,x)((r-1)*phi*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r));
[beta,R,J,CovB,MSE,ErrorModelInfo]=nlinfit(xdata,ydata,modelfun_n_m,[0.0,0.0]);
alpha = 0.05;
ci = nlparci(beta,R,J,alpha); % 95% confidence intervals,
n = tinv(1-alpha/2,length(ydata)-length(beta));
nlinfit_se = (ci(:,2)-ci(:,1)) ./ (2*n)  % Standard Error
[ypred,delta] = nlpredci(modelfun_n_m,x,beta,R,'Covar',CovB,...
                         'MSE',MSE,'SimOpt','on');   

lower = ypred - delta;
upper = ypred + delta;
p11 = plot(xdata,ydata,'b s') % observed data
hold on
p12 = plot(x,ypred,'b -.','LineWidth',1)
plot(x,[lower;upper],'b--','LineWidth',0.5)
errorbar(xdata,ydata,err,'b s')
mu_XJ33 = beta(1);
mu_XJ33_sigma = num2str(nlinfit_se(1));
t_XJ33 = beta(2);
t_XJ33_sigma = num2str(nlinfit_se(2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
file = 'XJ42.txt';
a= load(file);
xdata = a(:,1);ydata=a(:,2);
err = a(:,3);

mmodelfun_n_m = @(b,x)((r-1)*phi*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r));
[beta,R,J,CovB,MSE,ErrorModelInfo]=nlinfit(xdata,ydata,modelfun_n_m,[0.0,0.0]);
alpha = 0.05;
ci = nlparci(beta,R,J,alpha); % 95% confidence intervals,
n = tinv(1-alpha/2,length(ydata)-length(beta));
nlinfit_se = (ci(:,2)-ci(:,1)) ./ (2*n)  % Standard Error
[ypred,delta] = nlpredci(modelfun_n_m,x,beta,R,'Covar',CovB,...
                         'MSE',MSE,'SimOpt','on');   

lower = ypred - delta;
upper = ypred + delta;
%figure()
p13 = plot(xdata,ydata,'b o') % observed data
hold on
p14 = plot(x,ypred,'b :.','LineWidth',1)
plot(x,[lower;upper],'b--','LineWidth',0.5)
errorbar(xdata,ydata,err,'b o')
mu_XJ42 = beta(1);
mu_XJ42_sigma = num2str(nlinfit_se(1));
t_XJ42 = beta(2);
t_XJ42_sigma = num2str(nlinfit_se(2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
file = 'XJ55.txt';
a= load(file);
xdata = a(:,1);ydata=a(:,2);
err = a(:,3);

mmodelfun_n_m = @(b,x)((r-1)*phi*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r));
[beta,R,J,CovB,MSE,ErrorModelInfo]=nlinfit(xdata,ydata,modelfun_n_m,[0.0,0.0]);
alpha = 0.05;
ci = nlparci(beta,R,J,alpha); % 95% confidence intervals,
n = tinv(1-alpha/2,length(ydata)-length(beta));
nlinfit_se = (ci(:,2)-ci(:,1)) ./ (2*n)  % Standard Error
[ypred,delta] = nlpredci(modelfun_n_m,x,beta,R,'Covar',CovB,...
                         'MSE',MSE,'SimOpt','on');   

lower = ypred - delta;
upper = ypred + delta;
%figure()
p15 = plot(xdata,ydata,'b ^') % observed data
hold on
p16 = plot(x,ypred,'b :','LineWidth',1)
plot(x,[lower;upper],'b--','LineWidth',0.5)
errorbar(xdata,ydata,err,'b ^')
mu_XJ55 = beta(1);
mu_XJ55_sigma = num2str(nlinfit_se(1));
t_XJ55 = beta(2);
t_XJ55_sigma = num2str(nlinfit_se(2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
file = 'XJ57.txt';
a= load(file);
xdata = a(:,1);ydata=a(:,2);
err = a(:,3);

mmodelfun_n_m = @(b,x)((r-1)*phi*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r));
[beta,R,J,CovB,MSE,ErrorModelInfo]=nlinfit(xdata,ydata,modelfun_n_m,[0.0,0.0]);
alpha = 0.05;
ci = nlparci(beta,R,J,alpha); % 95% confidence intervals,
n = tinv(1-alpha/2,length(ydata)-length(beta));
nlinfit_se = (ci(:,2)-ci(:,1)) ./ (2*n)  % Standard Error
[ypred,delta] = nlpredci(modelfun_n_m,x,beta,R,'Covar',CovB,...
                         'MSE',MSE,'SimOpt','on');   

lower = ypred - delta;
upper = ypred + delta;
%figure()
p17 = plot(xdata,ydata,'m s','MarkerFaceColor','m') % observed data
hold on
p18 = plot(x,ypred,'m -','LineWidth',1)
plot(x,[lower;upper],'m--','LineWidth',0.5)
errorbar(xdata,ydata,err,'m s')
mu_XJ57 = beta(1);
mu_XJ57_sigma = num2str(nlinfit_se(1));
t_XJ57 = beta(2);
t_XJ57_sigma = num2str(nlinfit_se(2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
file = 'XJ58.txt';
a= load(file);
xdata = a(:,1);ydata=a(:,2);
err = a(:,3);

mmodelfun_n_m = @(b,x)((r-1)*phi*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r));
[beta,R,J,CovB,MSE,ErrorModelInfo]=nlinfit(xdata,ydata,modelfun_n_m,[0.0,0.0]);
alpha = 0.05;
ci = nlparci(beta,R,J,alpha); % 95% confidence intervals,
n = tinv(1-alpha/2,length(ydata)-length(beta));
nlinfit_se = (ci(:,2)-ci(:,1)) ./ (2*n)  % Standard Error
[ypred,delta] = nlpredci(modelfun_n_m,x,beta,R,'Covar',CovB,...
                         'MSE',MSE,'SimOpt','on');   

lower = ypred - delta;
upper = ypred + delta;
%figure()
p19 = plot(xdata,ydata,'g d') % observed data
hold on
p20 = plot(x,ypred,'g -','LineWidth',1)
plot(x,[lower;upper],'g--','LineWidth',0.5)
errorbar(xdata,ydata,err,'g d')
mu_XJ58 = beta(1);
mu_XJ58_sigma = num2str(nlinfit_se(1));
t_XJ58 = beta(2);
t_XJ58_sigma = num2str(nlinfit_se(2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
file = 'XJ62.txt';
a= load(file);
xdata = a(:,1);ydata=a(:,2);
err = a(:,3);

mmodelfun_n_m = @(b,x)((r-1)*phi*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r));
[beta,R,J,CovB,MSE,ErrorModelInfo]=nlinfit(xdata,ydata,modelfun_n_m,[0.0,0.0]);
alpha = 0.05;
ci = nlparci(beta,R,J,alpha); % 95% confidence intervals,
n = tinv(1-alpha/2,length(ydata)-length(beta));
nlinfit_se = (ci(:,2)-ci(:,1)) ./ (2*n)  % Standard Error
[ypred,delta] = nlpredci(modelfun_n_m,x,beta,R,'Covar',CovB,...
                         'MSE',MSE,'SimOpt','on');   

lower = ypred - delta;
upper = ypred + delta;
%figure()
p21 = plot(xdata,ydata,'g s') % observed data
hold on
p22 = plot(x,ypred,'g -.','LineWidth',1)
plot(x,[lower;upper],'g--','LineWidth',0.5)
errorbar(xdata,ydata,err,'g s')
mu_XJ62 = beta(1);
mu_XJ62_sigma = num2str(nlinfit_se(1));
t_XJ62 = beta(2);
t_XJ62_sigma = num2str(nlinfit_se(2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
file = 'XJ63.txt';
a= load(file);
xdata = a(:,1);ydata=a(:,2);
err = a(:,3);

mmodelfun_n_m = @(b,x)((r-1)*phi*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r));
[beta,R,J,CovB,MSE,ErrorModelInfo]=nlinfit(xdata,ydata,modelfun_n_m,[0.0,0.0]);
alpha = 0.05;
ci = nlparci(beta,R,J,alpha); % 95% confidence intervals,
n = tinv(1-alpha/2,length(ydata)-length(beta));
nlinfit_se = (ci(:,2)-ci(:,1)) ./ (2*n)  % Standard Error
[ypred,delta] = nlpredci(modelfun_n_m,x,beta,R,'Covar',CovB,...
                         'MSE',MSE,'SimOpt','on');   

lower = ypred - delta;
upper = ypred + delta;
%figure()
p23 = plot(xdata,ydata,'g o') % observed data
hold on
p24 = plot(x,ypred,'g :','LineWidth',1)
plot(x,[lower;upper],'g--','LineWidth',0.5)
errorbar(xdata,ydata,err,'g o')
mu_XJ63 = beta(1);
mu_XJ63_sigma = num2str(nlinfit_se(1));
t_XJ63 = beta(2);
t_XJ63_sigma = num2str(nlinfit_se(2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
file = 'XJ65.txt';
a= load(file);
xdata = a(:,1);ydata=a(:,2);
err = a(:,3);

mmodelfun_n_m = @(b,x)((r-1)*phi*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r));
[beta,R,J,CovB,MSE,ErrorModelInfo]=nlinfit(xdata,ydata,modelfun_n_m,[0.0,0.0]);
alpha = 0.05;
ci = nlparci(beta,R,J,alpha); % 95% confidence intervals,
n = tinv(1-alpha/2,length(ydata)-length(beta));
nlinfit_se = (ci(:,2)-ci(:,1)) ./ (2*n)  % Standard Error
[ypred,delta] = nlpredci(modelfun_n_m,x,beta,R,'Covar',CovB,...
                         'MSE',MSE,'SimOpt','on');   

lower = ypred - delta;
upper = ypred + delta;
%figure()
p25 = plot(xdata,ydata,'g ^') % observed data
hold on
p26 = plot(x,ypred,'g :.','LineWidth',1)
plot(x,[lower;upper],'g--','LineWidth',0.5)
errorbar(xdata,ydata,err,'g ^')
mu_XJ65 = beta(1);
mu_XJ65_sigma = num2str(nlinfit_se(1));
t_XJ65 = beta(2);
t_XJ65_sigma = num2str(nlinfit_se(2));


h=gca;%���������
xlim ([0, 24]);
ylim ([0, 1.2]);
set(h,'xtick',[0 2 4 6 8 10 12 14 16 18 20 22 24]);%������������ʾ��x�������ϵĵ�
set(h,'ytick',[0 0.2 0.4 0.6 0.8 1.0 1.2]);
legend1 = legend([p25 p23 p21 p19 p17 p15 p13 p11 p9 p7 p5 p3 p1],{'XJ65','XJ63','XJ62','XJ58','XJ57','XJ55','XJ42','XJ33','XJ13','XJ6','XJ2','XJ1','XJ3E'})
legend('boxoff')
hold on;
ah=axes('position',get(gca,'position'),'visible','off');
legend2 = legend(ah, [p26 p24, p22, p20, p18, p16, p14, p12, p10, p8, p6, p4, p2],{'','','','','','','','','','','','','','',''})
%legend1=legend('Location','East')
set(legend1,'FontSize',9,'FontWeight','normal')
set(legend2,'FontSize',9,'FontWeight','normal')
%set(legend1,'FontName','Times New Roman','FontSize',12,'FontWeight','normal')
legend('boxoff')