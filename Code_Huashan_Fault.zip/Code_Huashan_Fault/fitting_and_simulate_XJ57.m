clear all;
clc;

x = 0:0.1:36;% mm
t = 0.00264;
F = 3.7/506.0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
file = 'XJ3E.txt';
a= load(file);
xdata = a(:,1);ydata = a(:,2);
err = a(:,3);

r = 1.9;
modelfun_m = @(b,x)((r-1)*t*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r));
[beta,R,J,CovB,MSE,ErrorModelInfo]=nlinfit(xdata,ydata,modelfun_m,[0.0,0.0]);
alpha = 0.05;
ci = nlparci(beta,R,J,alpha); % 95% confidence intervals,
n = tinv(1-alpha/2,length(ydata)-length(beta));
nlinfit_se = (ci(:,2)-ci(:,1)) ./ (2*n)  % Standard Error
[ypred,delta] = nlpredci(modelfun_m,x,beta,R,'Covar',CovB,...
                         'MSE',MSE,'SimOpt','on');                    
lower = ypred - delta;
upper = ypred + delta;

mu_XJ3E = beta(1);
phi_XJ3E = beta(2);
phi = beta(2);
mu_XJ3E_sigma = num2str(nlinfit_se(1));
phi_XJ3E_sigma = num2str(nlinfit_se(2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
file = 'XJ1_55_erosion.txt';
a= load(file);
xdata = a(:,1);ydata=a(:,2);
err = a(:,3);
modelfun_n_m = @(b,x)((r-1)*phi*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r));
[beta,R,J,CovB,MSE,ErrorModelInfo]=nlinfit(xdata,ydata,modelfun_n_m,[0.0,0.0]);
alpha = 0.05;
ci = nlparci(beta,R,J,alpha); % 95% confidence intervals,
n = tinv(1-alpha/2,length(ydata)-length(beta));
nlinfit_se = (ci(:,2)-ci(:,1)) ./ (2*n)  % Standard Error
[ypred,delta] = nlpredci(modelfun_n_m,x,beta,R,'Covar',CovB,...
                         'MSE',MSE,'SimOpt','on');   

lower = ypred - delta;
upper = ypred + delta;
% % % p3 = plot(xdata,ydata,'b o','MarkerFaceColor','b') % observed data
% % % hold on
% % % p4 = plot(x,ypred,'b ','LineWidth',2)
% % % plot(x,[lower;upper],'b--','LineWidth',0.5)
% % % errorbar(xdata,ydata,err,'b o')
mu_XJ1_55 = beta(1);
mu_XJ1_55_sigma = num2str(nlinfit_se(1));
t_XJ1_55 = beta(2);
t_XJ1_55_sigma = num2str(nlinfit_se(2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
file = 'XJ58_65_erosion.txt';
a= load(file);
xdata = a(:,1);ydata=a(:,2);
err = a(:,3);

modelfun_m = @(b,x)((r-1)*phi*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r));
[beta,R,J,CovB,MSE,ErrorModelInfo]=nlinfit(xdata,ydata,modelfun_m,[0.0,0.0]);
alpha = 0.05;
ci = nlparci(beta,R,J,alpha); % 95% confidence intervals,
n = tinv(1-alpha/2,length(ydata)-length(beta));
nlinfit_se = (ci(:,2)-ci(:,1)) ./ (2*n)  % Standard Error
[ypred,delta] = nlpredci(modelfun_m,x,beta,R,'Covar',CovB,...
                         'MSE',MSE,'SimOpt','on');   

lower = ypred - delta;
upper = ypred + delta;
% % % p5 = plot(xdata,ydata,'g ^') % observed data
% % % hold on
% % % p6 = plot(x,ypred,'g ','LineWidth',2)
% % % plot(x,[lower;upper],'g--','LineWidth',0.5)
% % % errorbar(xdata,ydata,err,'g ^')
mu_XJ58_65 = beta(1);
mu_XJ58_65_sigma = num2str(nlinfit_se(1));
t_XJ58_65 = beta(2);
t_XJ58_65_sigma = num2str(nlinfit_se(2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

file = 'XJ57_erosion.txt';
a= load(file);
xdata = a(:,1);ydata=a(:,2);
err = a(:,3);
% % % modelfun_m = @(b,x)((r-1)*phi*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r));
modelfun_m = @(b,x)(((((r-1)*phi*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r))-1).*exp(-1.0*F*(t_XJ58_65-0.5))+1).*((r-1)*phi*(0.5-b(2))*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r)));
% The combined duration of the two exposure periods is 0.5ka.

[beta,R,J,CovB,MSE,ErrorModelInfo]=nlinfit(xdata,ydata,modelfun_m,[1.1,0.1]);
alpha = 0.05;
ci = nlparci(beta,R,J,alpha); % 95% confidence intervals,
n = tinv(1-alpha/2,length(ydata)-length(beta));
nlinfit_se = (ci(:,2)-ci(:,1)) ./ (2*n)  % Standard Error
[ypred,delta] = nlpredci(modelfun_m,x,beta,R,'Covar',CovB,...
                         'MSE',MSE,'SimOpt','on');   

lower = ypred - delta;
upper = ypred + delta;
figure()
% % % p7 = plot(xdata,ydata,'m s','MarkerFaceColor','m') % observed data
p7 = semilogy(xdata,ydata,'m s','MarkerFaceColor','m')
hold on
p8 = plot(x,ypred,'m -','LineWidth',1)
plot(x,[lower;upper],'m--','LineWidth',0.5)
errorbar(xdata,ydata,err,'m s')

hold on;
fx = 0.0:0.01:30;
modelfun = @(b,x)(((((r-1)*phi*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r))-1).*exp(-1.0*F*b(3))+1).*((r-1)*phi*b(4)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r)));
beta1 = [0.59,0.0273,0,0];
fy1 = modelfun(beta1,fx);
p9 = plot(fx,fy1,'-r','DisplayName','best-fit of D','Linewidth',1.2)
hold on;
beta2 = [0.59,0.0273,0.57,0];
fy2 = modelfun(beta2,fx);
p10 = plot(fx,fy2,'-k','DisplayName','best-fit of D','Linewidth',1.2)
hold on;
beta3 = [0.59,0.0273,0.57,0.5];
fy3 = modelfun(beta3,fx);
p11 = plot(fx,fy3,'-b','DisplayName','best-fit of D','Linewidth',1.2)

hold on;
h=gca;%���������
xlim ([0, 30]);
ylim ([10^-4, 1.2]);
legend('boxoff')
xlabel('Depth (mm)')
ylabel('Norm. Sens. Corr. IRSL (Ln/Tn)')
set(h,'xtick',[0 2 4 6 8 10 12 14 16 18 20 22 24 26 28 30]);%������������ʾ��x�������ϵĵ�
set(h,'ytick',[10^-3 10^-2 10^-1 10^0]);
legend1 = legend([p7],{'XJ57'})
legend('boxoff')
hold on;
ah=axes('position',get(gca,'position'),'visible','off');
legend2 = legend(ah,[p8],{'Best-fit of XJ57'})
legend('boxoff')
hold on;
ah=axes('position',get(gca,'position'),'visible','off');
legend3 = legend(ah,[p9],{'First exposure simulation'})
legend('boxoff')
hold on;
ah=axes('position',get(gca,'position'),'visible','off');
legend4 = legend(ah,[p10],{'Exposure-burial simulation'})
legend('boxoff')
hold on;
ah=axes('position',get(gca,'position'),'visible','off');
legend5 = legend(ah,[p11],{'Exposure-burial-exposure simulation'})
legend('boxoff')
xlabel('Depth (mm)')
ylabel('Norm. Sens. Corr. IRSL (Ln/Tn)')

mu_XJ57 = beta(1);
mu_XJ57_sigma = num2str(nlinfit_se(1));
t_XJ57 = beta(2);
t_XJ57_sigma = num2str(nlinfit_se(2));
% % % tb1 = beta(3);
% % % te2 = beta(4);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure()
p12 = plot(xdata,ydata,'m s','MarkerFaceColor','m')
hold on;
p13 = plot(x,ypred,'m -','LineWidth',1)
plot(x,[lower;upper],'m--','LineWidth',0.5)
errorbar(xdata,ydata,err,'m s')

hold on;
fx = 0.0:0.01:30;
modelfun = @(b,x)(((((r-1)*phi*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r))-1).*exp(-1.0*F*b(3))+1).*((r-1)*phi*b(4)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r)));
beta1 = [0.59,0.0273,0,0];
fy1 = modelfun(beta1,fx);
p14 = plot(fx,fy1,'-r','DisplayName','best-fit of D','Linewidth',1.2)
hold on;
beta2 = [0.59,0.0273,0.57,0];
fy2 = modelfun(beta2,fx);
p15 = plot(fx,fy2,'-k','DisplayName','best-fit of D','Linewidth',1.2)
hold on;
beta3 = [0.59,0.0273,0.57,0.5];
fy3 = modelfun(beta3,fx);
p16 = plot(fx,fy3,'-b','DisplayName','best-fit of D','Linewidth',1.2)

hold on;
h=gca;%���������
xlim ([0, 30]);
ylim ([0, 1.2]);
legend('boxoff')
xlabel('Depth (mm)')
ylabel('Norm. Sens. Corr. IRSL (Ln/Tn)')
set(h,'xtick',[0 2 4 6 8 10 12 14 16 18 20 22 24 26 28 30]);%������������ʾ��x�������ϵĵ�
set(h,'ytick',[0 0.2 0.4 0.6 0.8 1.0 1.2]);
legend1 = legend([p12],{'XJ57'})
legend('boxoff')
hold on;
ah=axes('position',get(gca,'position'),'visible','off');
legend2 = legend(ah,[p13],{'Best-fit of XJ57'})
legend('boxoff')
hold on;
ah=axes('position',get(gca,'position'),'visible','off');
legend14 = legend(ah,[p14],{'First exposure simulation'})
legend('boxoff')
hold on;
ah=axes('position',get(gca,'position'),'visible','off');
legend15 = legend(ah,[p15],{'Exposure-burial simulation'})
legend('boxoff')
hold on;
ah=axes('position',get(gca,'position'),'visible','off');
legend16 = legend(ah,[p16],{'Exposure-burial-exposure simulation'})
legend('boxoff')