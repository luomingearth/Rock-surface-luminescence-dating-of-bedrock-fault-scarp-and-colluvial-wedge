clear all;
clc;

x = 0:0.1:36;% mm
t = 0.00264;
F = 3.7/506.0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
file = 'XJ3E.txt';
a= load(file);
xdata = a(:,1);ydata = a(:,2);
err = a(:,3);

r = 1.9;
modelfun_n_m = @(b,x)((r-1)*t*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r));
[beta,R,J,CovB,MSE,ErrorModelInfo]=nlinfit(xdata,ydata,modelfun_n_m,[0.0,0.0]);
alpha = 0.05;
ci = nlparci(beta,R,J,alpha); % 95% confidence intervals,
n = tinv(1-alpha/2,length(ydata)-length(beta));
nlinfit_se = (ci(:,2)-ci(:,1)) ./ (2*n)  % Standard Error
[ypred,delta] = nlpredci(modelfun_n_m,x,beta,R,'Covar',CovB,...
                         'MSE',MSE,'SimOpt','on');                    
lower = ypred - delta;
upper = ypred + delta;

figure()
h=gca;%���������
box on;
p1 = plot(xdata,ydata,'r o','MarkerFaceColor','r') %���ݵ�
%%%p7 = plot(xdata,ydata,'r o','MarkerFaceColor','r') % observed data ʵ��
hold on
p2 = plot(x,ypred,'r-','LineWidth',1) %���������
plot(x,[lower;upper],'r--','LineWidth',0.5) %��������
errorbar(xdata,ydata,err,'r o') %���

xlabel('Depth (mm)')
ylabel('Norm. Sens. Corr. IRSL (Ln/Tn)')
mu_XJ3E = beta(1);
phi_XJ3E = beta(2);
phi = beta(2);
mu_XJ3E_sigma = num2str(nlinfit_se(1));
phi_XJ3E_sigma = num2str(nlinfit_se(2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
file = 'XJ1_55_erosion.txt';
a= load(file);
xdata = a(:,1);ydata=a(:,2);
err = a(:,3);
modelfun_n_m = @(b,x)((r-1)*phi*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r));
[beta,R,J,CovB,MSE,ErrorModelInfo]=nlinfit(xdata,ydata,modelfun_n_m,[0.0,0.0]);
alpha = 0.05;
ci = nlparci(beta,R,J,alpha); % 95% confidence intervals,
n = tinv(1-alpha/2,length(ydata)-length(beta));
nlinfit_se = (ci(:,2)-ci(:,1)) ./ (2*n)  % Standard Error
[ypred,delta] = nlpredci(modelfun_n_m,x,beta,R,'Covar',CovB,...
                         'MSE',MSE,'SimOpt','on');   

lower = ypred - delta;
upper = ypred + delta;
%figure()
p3 = plot(xdata,ydata,'b o','MarkerFaceColor','b') % observed data
hold on
p4 = plot(x,ypred,'b ','LineWidth',2)
plot(x,[lower;upper],'b--','LineWidth',0.5)
errorbar(xdata,ydata,err,'b o')
mu_XJ1_55 = beta(1);
mu_XJ1_55_sigma = num2str(nlinfit_se(1));
t_XJ1_55 = beta(2);
t_XJ1_55_sigma = num2str(nlinfit_se(2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
file = 'XJ57_erosion.txt';
a= load(file);
xdata = a(:,1);ydata=a(:,2);
err = a(:,3);

modelfun_n_m = @(b,x)((r-1)*phi*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r));
% % % modelfun_n_m = @(b,x)((((r-1)*phi*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r))-1)*exp(-1.0*F*(1.3526-b(1)))+1);
[beta,R,J,CovB,MSE,ErrorModelInfo]=nlinfit(xdata,ydata,modelfun_n_m,[0.0,0.0]);
alpha = 0.05;
ci = nlparci(beta,R,J,alpha); % 95% confidence intervals,
n = tinv(1-alpha/2,length(ydata)-length(beta));
nlinfit_se = (ci(:,2)-ci(:,1)) ./ (2*n)  % Standard Error
[ypred,delta] = nlpredci(modelfun_n_m,x,beta,R,'Covar',CovB,...
                         'MSE',MSE,'SimOpt','on');   

lower = ypred - delta;
upper = ypred + delta;
%figure()
p5 = plot(xdata,ydata,'m s','MarkerFaceColor','m') % observed data
hold on
p6 = plot(x,ypred,'m -','LineWidth',1)
plot(x,[lower;upper],'m--','LineWidth',0.5)
errorbar(xdata,ydata,err,'m s')
mu_XJ57 = beta(1);
mu_XJ57_sigma = num2str(nlinfit_se(1));
t_XJ57 = beta(2);
t_XJ57_sigma = num2str(nlinfit_se(2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
file = 'XJ58_65_erosion.txt';
a= load(file);
xdata = a(:,1);ydata=a(:,2);
err = a(:,3);

modelfun_n_m = @(b,x)((r-1)*phi*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r));
[beta,R,J,CovB,MSE,ErrorModelInfo]=nlinfit(xdata,ydata,modelfun_n_m,[0.0,0.0]);
alpha = 0.05;
ci = nlparci(beta,R,J,alpha); % 95% confidence intervals,
n = tinv(1-alpha/2,length(ydata)-length(beta));
nlinfit_se = (ci(:,2)-ci(:,1)) ./ (2*n)  % Standard Error
[ypred,delta] = nlpredci(modelfun_n_m,x,beta,R,'Covar',CovB,...
                         'MSE',MSE,'SimOpt','on');   

lower = ypred - delta;
upper = ypred + delta;
%figure()
p7 = plot(xdata,ydata,'g ^') % observed data
hold on
p8 = plot(x,ypred,'g ','LineWidth',2)
plot(x,[lower;upper],'g--','LineWidth',0.5)
errorbar(xdata,ydata,err,'g ^')
mu_XJ58_65 = beta(1);
mu_XJ58_65_sigma = num2str(nlinfit_se(1));
t_XJ58_65 = beta(2);
t_XJ58_65_sigma = num2str(nlinfit_se(2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
file = 'XJ2B.txt';
a= load(file);
xdata = a(:,1);ydata=a(:,2);
err = a(:,3);

% % % modelfun_n_m = @(b,x)((r-1)*phi*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r));
modelfun_n_m = @(b,x)((((r-1)*phi*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r))-1)*exp(-1.0*F*(t_XJ1_55-b(2)))+1);

[beta,R,J,CovB,MSE,ErrorModelInfo]=nlinfit(xdata,ydata,modelfun_n_m,[0.0,0.0]);
alpha = 0.05;
ci = nlparci(beta,R,J,alpha); % 95% confidence intervals,
n = tinv(1-alpha/2,length(ydata)-length(beta));
nlinfit_se = (ci(:,2)-ci(:,1)) ./ (2*n)  % Standard Error
[ypred,delta] = nlpredci(modelfun_n_m,x,beta,R,'Covar',CovB,...
                         'MSE',MSE,'SimOpt','on');   

lower = ypred - delta;
upper = ypred + delta;
%figure()
p9 = plot(xdata,ydata,'k ^') % observed data
hold on
p10 = plot(x,ypred,'k -.','LineWidth',1)
plot(x,[lower;upper],'k--','LineWidth',0.5)
errorbar(xdata,ydata,err,'k ^')
mu_XJ2B = beta(1);
mu_XJ2B_sigma = num2str(nlinfit_se(1));
t_XJ2B = beta(2);
t_XJ2B_sigma = num2str(nlinfit_se(2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
file = 'XJ4B.txt';
a= load(file);
xdata = a(:,1);ydata=a(:,2);
err = a(:,3);

modelfun_n_m = @(b,x)((((r-1)*phi*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r))-1)*exp(-1.0*F*(t_XJ1_55-b(2)))+1);
[beta,R,J,CovB,MSE,ErrorModelInfo]=nlinfit(xdata,ydata,modelfun_n_m,[0.0,0.0]);
alpha = 0.05;
ci = nlparci(beta,R,J,alpha); % 95% confidence intervals,
n = tinv(1-alpha/2,length(ydata)-length(beta));
nlinfit_se = (ci(:,2)-ci(:,1)) ./ (2*n)  % Standard Error
[ypred,delta] = nlpredci(modelfun_n_m,x,beta,R,'Covar',CovB,...
                         'MSE',MSE,'SimOpt','on');   

lower = ypred - delta;
upper = ypred + delta;
%figure()
p11 = plot(xdata,ydata,'k o') % observed data
hold on
% % % p12 = plot(x,ypred,'k :','LineWidth',1)
p12 = plot(x,ypred,'k -','LineWidth',1)
plot(x,[lower;upper],'k--','LineWidth',0.5)
errorbar(xdata,ydata,err,'k o')
mu_XJ4B = beta(1);
mu_XJ4B_sigma = num2str(nlinfit_se(1));
t_XJ4B = beta(2);
t_XJ4B_sigma = num2str(nlinfit_se(2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
file = 'XJ5B_6B_7B.txt';
a= load(file);
xdata = a(:,1);ydata=a(:,2);
err = a(:,3);

modelfun_n_m = @(b,x)((((r-1)*phi*b(2)*exp(-1.0*b(1)*x) + 1).^(1 / (1 - r))-1)*exp(-1.0*F*(t_XJ1_55-b(2)))+1);
[beta,R,J,CovB,MSE,ErrorModelInfo]=nlinfit(xdata,ydata,modelfun_n_m,[0.0,0.0]);
alpha = 0.05;
ci = nlparci(beta,R,J,alpha); % 95% confidence intervals,
n = tinv(1-alpha/2,length(ydata)-length(beta));
nlinfit_se = (ci(:,2)-ci(:,1)) ./ (2*n)  % Standard Error
[ypred,delta] = nlpredci(modelfun_n_m,x,beta,R,'Covar',CovB,...
                         'MSE',MSE,'SimOpt','on');   

lower = ypred - delta;
upper = ypred + delta;
%figure()
p13 = plot(xdata,ydata,'k s','MarkerFaceColor','k') % observed data
hold on
% % % p14 = plot(x,ypred,'k :.','LineWidth',1)
p14 = plot(x,ypred,'k -','LineWidth',2)
plot(x,[lower;upper],'k--','LineWidth',0.5)
errorbar(xdata,ydata,err,'k s')
mu_XJ5B_6B_7B = beta(1);
mu_XJ5B_6B_7B_sigma = num2str(nlinfit_se(1));
t_XJ5B_6B_7B = beta(2);
t_XJ5B_6B_7B_sigma = num2str(nlinfit_se(2));



h=gca;%���������
xlim ([0, 36]);
ylim ([0, 1.2]);
set(h,'xtick',[0 2 4 6 8 10 12 14 16 18 20 22 24 26 28 30 32 34]);%������������ʾ��x�������ϵĵ�
set(h,'ytick',[0 0.2 0.4 0.6 0.8 1.0 1.2]);
legend1 = legend([p7 p5 p3 p9 p11 p13 p1],{'XJ58-XJ65','XJ57','XJ1-XJ55','XJ2B','XJ4B','XJ5B-XJ7B','XJ3E'})
legend('boxoff')
hold on;
ah=axes('position',get(gca,'position'),'visible','off');
legend2 = legend(ah, [p8, p6 p4, p10, p12, p14, p2],{'','','','','','','',''})
%legend1=legend('Location','East')
set(legend1,'FontSize',9,'FontWeight','normal')
set(legend2,'FontSize',9,'FontWeight','normal')
%set(legend1,'FontName','Times New Roman','FontSize',12,'FontWeight','normal')
legend('boxoff')