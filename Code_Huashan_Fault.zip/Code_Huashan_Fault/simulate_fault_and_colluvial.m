clear;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%own done
F=6/250;
phi=2200;
mu=0.6;

modelfun = @(b,x)(exp(-1.0*b(3)*phi*exp(-1.0*mu*x)).*(exp(-1.0*F*b(2))*(exp(-1.0*b(1)*phi*exp(-1.0*mu*x))-1)+1));
%b(1): te1; b(2):tb1; b(3): te2
%%
Ax = 0.0:1:30;
Bx = 0.3:1:30;
Cx = 0.6:1:30;
Dx = 0.0:1:30;
Ex = 0.3:1:30;
Fx = 0.6:1:30;
Gx = 0.0:1:30;
Hx = 0.3:1:30;
Ix = 1.0:2:30;
Jx = 0.0:2:30;

fx = 0.0:0.01:30;

beta1 = [10,0,0];
Ay = modelfun(beta1,Ax);
fy = modelfun(beta1,fx);
figure()
hold on
p1 = plot(Ax,Ay,'^g','DisplayName','A','Linewidth',1.2)
%plot(fx,fy,'-k','DisplayName','best-fit of A')
beta2 = [10,0,0];
By = modelfun(beta2,Bx);
fy2 = modelfun(beta2,fx);
p2 = plot(Bx,By,'og','DisplayName','B','Linewidth',1.2)
beta3 = [10,0,0];
Cy = modelfun(beta3,Cx);
fy3 = modelfun(beta3,fx);
p3 = plot(Cx,Cy,'sg','DisplayName','C','Linewidth',1.2);
plot(fx,fy3,'-g','DisplayName','best-fit of A,B,C','Linewidth',1.2)

%mfun = @(b,x)(exp(-1.0*b(3)*phi*exp(-1.0*mu*x)).*(exp(-1.0*F*b(2))*(exp(-1.0*b(1)*phi*exp(-1.0*mu*x))-1)+1));
beta4 = [4,5,1];
Dy = modelfun(beta4,Dx);
fy4 = modelfun(beta4,fx);
p4 = plot(Dx,Dy,'m s','DisplayName','D','MarkerFaceColor','m','Linewidth',1.2);
plot(fx,fy4,'-m','DisplayName','best-fit of D','Linewidth',1.2)
%%
beta5 = [2,0,0];
Ey = modelfun(beta5,Ex);
fy5 = modelfun(beta5,fx);
p5 = plot(Ex,Ey,'^b','DisplayName','E','Linewidth',1.2)
beta6 = [2,0,0];
Fy = modelfun(beta6,Fx);
fy6 = modelfun(beta6,fx);
p6 = plot(Fx,Fy,'ob','DisplayName','F','Linewidth',1.2)
plot(fx,fy6,'-b','DisplayName','best-fit of E,F','Linewidth',1.2)

%%
beta7 = [0.2,1.8,0];
Gy = modelfun(beta7,Gx);
fy7 = modelfun(beta7,fx);
p7 = plot(Gx,Gy,'^k','DisplayName','G','Linewidth',1.2);
plot(fx,fy7,'-k','DisplayName','best-fit of G','Linewidth',1.2)

beta8 = [0.1,1.9,0];
Hy = modelfun(beta8,Hx);
fy8 = modelfun(beta8,fx);
p8 = plot(Hx,Hy,'s k','DisplayName','H','Linewidth',1.2)
plot(fx,fy8,'-k','DisplayName','best-fit of H','Linewidth',1.2)
%%
Iy = 1+Ix-Ix;
fy9 = 1+fx-fx;
p9 = plot(Ix,Iy,'x k','DisplayName','I','Linewidth',1.2)
% % % p9 = plot(Ix,Iy,'xk','DisplayName','I','Linewidth',1.2)

Jy = 1+Jx-Jx;
fy10 = 1+fx-fx;
p10 = plot(Jx,Jy,'ok','DisplayName','J','Linewidth',1.2)
plot(fx,fy10,'-k','DisplayName','best-fit of I,J','Linewidth',1.2)

box on;
xlim ([0, 20]);
ylim ([0, 1.2]);
xlabel('Depth (mm)')
ylabel('Luminescence intensity (a.u.)')
legend([p1 p2 p3 p4 p5 p6 p7 p8 p9 p10])
legend1=legend('Location','Best')
set(legend1,'FontWeight','normal')
legend('boxoff')

box on;
xlim ([0, 30]);
ylim ([0, 1.1]);

